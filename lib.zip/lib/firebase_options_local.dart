class FirebaseLocal {

  // Shared
  static const messagingSenderId = '585284151370';
  static const projectId = 'agenda-loja';
  static const storageBucket = 'agenda-loja.firebasestorage.app';
  
  // Web
  static const webApiKey = 'AIzaSyD37NgdFh9EjSax4r1H4UrM5S6GmQ_Xg4A';
  static const webAppId = '1:585284151370:web:6304404404c3e1006b9eb3';
  static const authDomain = 'agenda-loja.firebaseapp.com';
  static const measurementId = 'G-NP1D1KDKW7';

  // Android
  static const androidApiKey = 'AIzaSyDycv6JmfaXDztDg2sOvLJ36Oguk6UdsIg';
  static const androidAppId = '1:585284151370:android:d4a9324ae0810b276b9eb3';

  // iOS
  static const iosApiKey = 'AIzaSyAFZpXJb9X7NZ3AIkf8zEnSUSnuvxTmECA';
  static const iosAppId = '1:585284151370:ios:7e58fbd55a76010a6b9eb3';
  static const iosBundleId = 'com.example.financasHubApp';

  // macOS
  static const macosApiKey = 'AIzaSyAFZpXJb9X7NZ3AIkf8zEnSUSnuvxTmECA';
  static const macosAppId = '1:585284151370:ios:7e58fbd55a76010a6b9eb3';
  static const macosBundleId = 'com.example.financasHubApp';
  static const androidClientId = '585284151370-halnetcuc2k50qkfmj4tifu1ugs4rbd3.apps.googleusercontent.com';
  static const iosClientId = '585284151370-aipq07ertjgicr30c42843qn6ma0dv56.apps.googleusercontent.com';

  // Windows
  static const windowsApiKey = 'AIzaSyDHA83uaNQldxWWXtVar1oRO0XDHBIf718';
  static const windowsAppId = '1:585284151370:web:cadc7a1227f9f8466b9eb3';
  static const windowsAuthDomain =  'agenda-loja.firebaseapp.com';
  static const windowsMeasurementId = 'G-7N4SWP9F31';    
}