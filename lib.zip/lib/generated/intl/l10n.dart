// GENERATED CODE - DO NOT MODIFY BY HAND
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'intl/messages_all.dart';

// **************************************************************************
// Generator: Flutter Intl IDE plugin
// Made by Localizely
// **************************************************************************

// ignore_for_file: non_constant_identifier_names, lines_longer_than_80_chars
// ignore_for_file: join_return_with_assignment, prefer_final_in_for_each
// ignore_for_file: avoid_redundant_argument_values, avoid_escaping_inner_quotes

class S {
  S();

  static S? _current;

  static S get current {
    assert(_current != null,
        'No instance of S was loaded. Try to initialize the S delegate before accessing S.current.');
    return _current!;
  }

  static const AppLocalizationDelegate delegate = AppLocalizationDelegate();

  static Future<S> load(Locale locale) {
    final name = (locale.countryCode?.isEmpty ?? false)
        ? locale.languageCode
        : locale.toString();
    final localeName = Intl.canonicalizedLocale(name);
    return initializeMessages(localeName).then((_) {
      Intl.defaultLocale = localeName;
      final instance = S();
      S._current = instance;

      return instance;
    });
  }

  static S of(BuildContext context) {
    final instance = S.maybeOf(context);
    assert(instance != null,
        'No instance of S present in the widget tree. Did you add S.delegate in localizationsDelegates?');
    return instance!;
  }

  static S? maybeOf(BuildContext context) {
    return Localizations.of<S>(context, S);
  }

  /// `Finance`
  String get appTitle {
    return Intl.message(
      'Finance',
      name: 'appTitle',
      desc: '',
      args: [],
    );
  }

  /// `agenda-loja · owners only`
  String get loginSubtitle {
    return Intl.message(
      'agenda-loja · owners only',
      name: 'loginSubtitle',
      desc: '',
      args: [],
    );
  }

  /// `Continue with Google`
  String get loginButton {
    return Intl.message(
      'Continue with Google',
      name: 'loginButton',
      desc: '',
      args: [],
    );
  }

  /// `Restricted access · admins only`
  String get loginFooter {
    return Intl.message(
      'Restricted access · admins only',
      name: 'loginFooter',
      desc: '',
      args: [],
    );
  }

  /// `Not authorized for this access`
  String get loginErrorUnauthorized {
    return Intl.message(
      'Not authorized for this access',
      name: 'loginErrorUnauthorized',
      desc: '',
      args: [],
    );
  }

  /// `Authentication error ({code})`
  String loginErrorGeneric(Object code) {
    return Intl.message(
      'Authentication error ($code)',
      name: 'loginErrorGeneric',
      desc: '',
      args: [code],
    );
  }

  /// `No internet connection`
  String get loginErrorNetwork {
    return Intl.message(
      'No internet connection',
      name: 'loginErrorNetwork',
      desc: '',
      args: [],
    );
  }

  /// `Verifying...`
  String get loginVerifying {
    return Intl.message(
      'Verifying...',
      name: 'loginVerifying',
      desc: '',
      args: [],
    );
  }

  /// `this month`
  String get miniCardMonth {
    return Intl.message(
      'this month',
      name: 'miniCardMonth',
      desc: '',
      args: [],
    );
  }

  /// `revenue`
  String get miniCardRevenue {
    return Intl.message(
      'revenue',
      name: 'miniCardRevenue',
      desc: '',
      args: [],
    );
  }

  /// `occupancy`
  String get miniCardOccupancy {
    return Intl.message(
      'occupancy',
      name: 'miniCardOccupancy',
      desc: '',
      args: [],
    );
  }

  /// `Home`
  String get navDashboard {
    return Intl.message(
      'Home',
      name: 'navDashboard',
      desc: '',
      args: [],
    );
  }

  /// `Workers`
  String get navWorkers {
    return Intl.message(
      'Workers',
      name: 'navWorkers',
      desc: '',
      args: [],
    );
  }

  /// `Services`
  String get navServices {
    return Intl.message(
      'Services',
      name: 'navServices',
      desc: '',
      args: [],
    );
  }

  /// `Day`
  String get periodDay {
    return Intl.message(
      'Day',
      name: 'periodDay',
      desc: '',
      args: [],
    );
  }

  /// `Week`
  String get periodWeek {
    return Intl.message(
      'Week',
      name: 'periodWeek',
      desc: '',
      args: [],
    );
  }

  /// `Month`
  String get periodMonth {
    return Intl.message(
      'Month',
      name: 'periodMonth',
      desc: '',
      args: [],
    );
  }

  /// `Year`
  String get periodYear {
    return Intl.message(
      'Year',
      name: 'periodYear',
      desc: '',
      args: [],
    );
  }

  /// `Custom`
  String get periodCustom {
    return Intl.message(
      'Custom',
      name: 'periodCustom',
      desc: '',
      args: [],
    );
  }

  /// `Gross revenue`
  String get kpiGrossRevenue {
    return Intl.message(
      'Gross revenue',
      name: 'kpiGrossRevenue',
      desc: '',
      args: [],
    );
  }

  /// `Net profit`
  String get kpiNetRevenue {
    return Intl.message(
      'Net profit',
      name: 'kpiNetRevenue',
      desc: '',
      args: [],
    );
  }

  /// `Avg ticket`
  String get kpiAvgTicket {
    return Intl.message(
      'Avg ticket',
      name: 'kpiAvgTicket',
      desc: '',
      args: [],
    );
  }

  /// `Appointments`
  String get kpiCompletedAppointments {
    return Intl.message(
      'Appointments',
      name: 'kpiCompletedAppointments',
      desc: '',
      args: [],
    );
  }

  /// `Cancelled`
  String get kpiCancelledAppointments {
    return Intl.message(
      'Cancelled',
      name: 'kpiCancelledAppointments',
      desc: '',
      args: [],
    );
  }

  /// `Occupancy`
  String get kpiOccupancyRate {
    return Intl.message(
      'Occupancy',
      name: 'kpiOccupancyRate',
      desc: '',
      args: [],
    );
  }

  /// `Worker ranking`
  String get workerRanking {
    return Intl.message(
      'Worker ranking',
      name: 'workerRanking',
      desc: '',
      args: [],
    );
  }

  /// `Revenue`
  String get workerRevenue {
    return Intl.message(
      'Revenue',
      name: 'workerRevenue',
      desc: '',
      args: [],
    );
  }

  /// `Appointments`
  String get workerAppointments {
    return Intl.message(
      'Appointments',
      name: 'workerAppointments',
      desc: '',
      args: [],
    );
  }

  /// `% of total`
  String get workerShare {
    return Intl.message(
      '% of total',
      name: 'workerShare',
      desc: '',
      args: [],
    );
  }

  /// `Top services`
  String get workerTopServices {
    return Intl.message(
      'Top services',
      name: 'workerTopServices',
      desc: '',
      args: [],
    );
  }

  /// `Margin`
  String get serviceMargin {
    return Intl.message(
      'Margin',
      name: 'serviceMargin',
      desc: '',
      args: [],
    );
  }

  /// `Material cost`
  String get serviceCost {
    return Intl.message(
      'Material cost',
      name: 'serviceCost',
      desc: '',
      args: [],
    );
  }

  /// `Base price`
  String get serviceBasePrice {
    return Intl.message(
      'Base price',
      name: 'serviceBasePrice',
      desc: '',
      args: [],
    );
  }

  /// `Times performed`
  String get serviceTimesPerformed {
    return Intl.message(
      'Times performed',
      name: 'serviceTimesPerformed',
      desc: '',
      args: [],
    );
  }

  /// `Profitability`
  String get serviceProfitability {
    return Intl.message(
      'Profitability',
      name: 'serviceProfitability',
      desc: '',
      args: [],
    );
  }

  /// `Edit cost`
  String get editCost {
    return Intl.message(
      'Edit cost',
      name: 'editCost',
      desc: '',
      args: [],
    );
  }

  /// `Save`
  String get saveCost {
    return Intl.message(
      'Save',
      name: 'saveCost',
      desc: '',
      args: [],
    );
  }

  /// `No data for this period`
  String get noData {
    return Intl.message(
      'No data for this period',
      name: 'noData',
      desc: '',
      args: [],
    );
  }

  /// `Loading...`
  String get loading {
    return Intl.message(
      'Loading...',
      name: 'loading',
      desc: '',
      args: [],
    );
  }

  /// `Sign out`
  String get signOut {
    return Intl.message(
      'Sign out',
      name: 'signOut',
      desc: '',
      args: [],
    );
  }
}

class AppLocalizationDelegate extends LocalizationsDelegate<S> {
  const AppLocalizationDelegate();

  List<Locale> get supportedLocales {
    return const <Locale>[
      Locale.fromSubtags(languageCode: 'en'),
      Locale.fromSubtags(languageCode: 'es', countryCode: 'ES'),
      Locale.fromSubtags(languageCode: 'pt', countryCode: 'BR'),
    ];
  }

  @override
  bool isSupported(Locale locale) => _isSupported(locale);
  @override
  Future<S> load(Locale locale) => S.load(locale);
  @override
  bool shouldReload(AppLocalizationDelegate old) => false;

  bool _isSupported(Locale locale) {
    for (var supportedLocale in supportedLocales) {
      if (supportedLocale.languageCode == locale.languageCode) {
        return true;
      }
    }
    return false;
  }
}
