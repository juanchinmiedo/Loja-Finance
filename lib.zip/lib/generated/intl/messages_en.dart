// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a en locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'en';

  static String m0(code) => "Authentication error (${code})";

  final messages = _notInlinedMessages(_notInlinedMessages);
  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
    "appTitle": MessageLookupByLibrary.simpleMessage("Finance"),
    "editCost": MessageLookupByLibrary.simpleMessage("Edit cost"),
    "kpiAvgTicket": MessageLookupByLibrary.simpleMessage("Avg ticket"),
    "kpiCancelledAppointments": MessageLookupByLibrary.simpleMessage(
      "Cancelled",
    ),
    "kpiCompletedAppointments": MessageLookupByLibrary.simpleMessage(
      "Appointments",
    ),
    "kpiGrossRevenue": MessageLookupByLibrary.simpleMessage("Gross revenue"),
    "kpiNetRevenue": MessageLookupByLibrary.simpleMessage("Net profit"),
    "kpiOccupancyRate": MessageLookupByLibrary.simpleMessage("Occupancy"),
    "loading": MessageLookupByLibrary.simpleMessage("Loading..."),
    "loginButton": MessageLookupByLibrary.simpleMessage("Continue with Google"),
    "loginErrorGeneric": m0,
    "loginErrorNetwork": MessageLookupByLibrary.simpleMessage(
      "No internet connection",
    ),
    "loginErrorUnauthorized": MessageLookupByLibrary.simpleMessage(
      "Not authorized for this access",
    ),
    "loginFooter": MessageLookupByLibrary.simpleMessage(
      "Restricted access · admins only",
    ),
    "loginSubtitle": MessageLookupByLibrary.simpleMessage(
      "agenda-loja · owners only",
    ),
    "loginVerifying": MessageLookupByLibrary.simpleMessage("Verifying..."),
    "miniCardMonth": MessageLookupByLibrary.simpleMessage("this month"),
    "miniCardOccupancy": MessageLookupByLibrary.simpleMessage("occupancy"),
    "miniCardRevenue": MessageLookupByLibrary.simpleMessage("revenue"),
    "navDashboard": MessageLookupByLibrary.simpleMessage("Home"),
    "navServices": MessageLookupByLibrary.simpleMessage("Services"),
    "navWorkers": MessageLookupByLibrary.simpleMessage("Workers"),
    "noData": MessageLookupByLibrary.simpleMessage("No data for this period"),
    "periodCustom": MessageLookupByLibrary.simpleMessage("Custom"),
    "periodMonth": MessageLookupByLibrary.simpleMessage("Month"),
    "periodWeek": MessageLookupByLibrary.simpleMessage("Week"),
    "periodYear": MessageLookupByLibrary.simpleMessage("Year"),
    "saveCost": MessageLookupByLibrary.simpleMessage("Save"),
    "serviceBasePrice": MessageLookupByLibrary.simpleMessage("Base price"),
    "serviceCost": MessageLookupByLibrary.simpleMessage("Material cost"),
    "serviceMargin": MessageLookupByLibrary.simpleMessage("Margin"),
    "serviceProfitability": MessageLookupByLibrary.simpleMessage(
      "Profitability",
    ),
    "serviceTimesPerformed": MessageLookupByLibrary.simpleMessage(
      "Times performed",
    ),
    "signOut": MessageLookupByLibrary.simpleMessage("Sign out"),
    "workerAppointments": MessageLookupByLibrary.simpleMessage("Appointments"),
    "workerRanking": MessageLookupByLibrary.simpleMessage("Worker ranking"),
    "workerRevenue": MessageLookupByLibrary.simpleMessage("Revenue"),
    "workerShare": MessageLookupByLibrary.simpleMessage("% of total"),
    "workerTopServices": MessageLookupByLibrary.simpleMessage("Top services"),
  };
}
