// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a es_ES locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'es_ES';

  static String m0(code) => "Error de autenticación (${code})";

  final messages = _notInlinedMessages(_notInlinedMessages);
  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "appTitle": MessageLookupByLibrary.simpleMessage("Finanzas"),
        "editCost": MessageLookupByLibrary.simpleMessage("Editar coste"),
        "kpiAvgTicket": MessageLookupByLibrary.simpleMessage("Ticket medio"),
        "kpiCancelledAppointments":
            MessageLookupByLibrary.simpleMessage("Canceladas"),
        "kpiCompletedAppointments":
            MessageLookupByLibrary.simpleMessage("Citas completadas"),
        "kpiGrossRevenue":
            MessageLookupByLibrary.simpleMessage("Ingresos brutos"),
        "kpiNetRevenue": MessageLookupByLibrary.simpleMessage("Beneficio neto"),
        "kpiOccupancyRate": MessageLookupByLibrary.simpleMessage("Ocupación"),
        "loading": MessageLookupByLibrary.simpleMessage("Cargando..."),
        "loginButton":
            MessageLookupByLibrary.simpleMessage("Continuar con Google"),
        "loginErrorGeneric": m0,
        "loginErrorNetwork":
            MessageLookupByLibrary.simpleMessage("Sin conexión a internet"),
        "loginErrorUnauthorized": MessageLookupByLibrary.simpleMessage(
            "No autorizado para este acceso"),
        "loginFooter": MessageLookupByLibrary.simpleMessage(
            "Acceso restringido · solo administradores"),
        "loginSubtitle": MessageLookupByLibrary.simpleMessage(
            "agenda-loja · solo propietarios"),
        "loginVerifying":
            MessageLookupByLibrary.simpleMessage("Verificando..."),
        "miniCardMonth": MessageLookupByLibrary.simpleMessage("este mes"),
        "miniCardOccupancy": MessageLookupByLibrary.simpleMessage("ocupación"),
        "miniCardRevenue": MessageLookupByLibrary.simpleMessage("ingresos"),
        "navDashboard": MessageLookupByLibrary.simpleMessage("Inicio"),
        "navServices": MessageLookupByLibrary.simpleMessage("Servicios"),
        "navWorkers": MessageLookupByLibrary.simpleMessage("Workers"),
        "noData":
            MessageLookupByLibrary.simpleMessage("Sin datos para este período"),
        "periodCustom": MessageLookupByLibrary.simpleMessage("Personalizado"),
        "periodDay": MessageLookupByLibrary.simpleMessage("Día"),
        "periodMonth": MessageLookupByLibrary.simpleMessage("Mes"),
        "periodWeek": MessageLookupByLibrary.simpleMessage("Semana"),
        "periodYear": MessageLookupByLibrary.simpleMessage("Año"),
        "saveCost": MessageLookupByLibrary.simpleMessage("Guardar"),
        "serviceBasePrice": MessageLookupByLibrary.simpleMessage("Precio base"),
        "serviceCost": MessageLookupByLibrary.simpleMessage("Coste material"),
        "serviceMargin": MessageLookupByLibrary.simpleMessage("Margen"),
        "serviceProfitability":
            MessageLookupByLibrary.simpleMessage("Rentabilidad"),
        "serviceTimesPerformed":
            MessageLookupByLibrary.simpleMessage("Veces realizados"),
        "signOut": MessageLookupByLibrary.simpleMessage("Cerrar sesión"),
        "workerAppointments": MessageLookupByLibrary.simpleMessage("Citas"),
        "workerRanking":
            MessageLookupByLibrary.simpleMessage("Ranking de workers"),
        "workerRevenue": MessageLookupByLibrary.simpleMessage("Ingresos"),
        "workerShare": MessageLookupByLibrary.simpleMessage("% del total"),
        "workerTopServices":
            MessageLookupByLibrary.simpleMessage("Top servicios")
      };
}
