// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a pt_BR locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'pt_BR';

  static String m0(code) => "Erro de autenticação (${code})";

  final messages = _notInlinedMessages(_notInlinedMessages);
  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
    "appTitle": MessageLookupByLibrary.simpleMessage("Finanças"),
    "editCost": MessageLookupByLibrary.simpleMessage("Editar custo"),
    "kpiAvgTicket": MessageLookupByLibrary.simpleMessage("Ticket médio"),
    "kpiCancelledAppointments": MessageLookupByLibrary.simpleMessage(
      "Cancelados",
    ),
    "kpiCompletedAppointments": MessageLookupByLibrary.simpleMessage(
      "Atendimentos",
    ),
    "kpiGrossRevenue": MessageLookupByLibrary.simpleMessage("Receita bruta"),
    "kpiNetRevenue": MessageLookupByLibrary.simpleMessage("Lucro líquido"),
    "kpiOccupancyRate": MessageLookupByLibrary.simpleMessage("Ocupação"),
    "loading": MessageLookupByLibrary.simpleMessage("Carregando..."),
    "loginButton": MessageLookupByLibrary.simpleMessage("Continuar com Google"),
    "loginErrorGeneric": m0,
    "loginErrorNetwork": MessageLookupByLibrary.simpleMessage(
      "Sem conexão com a internet",
    ),
    "loginErrorUnauthorized": MessageLookupByLibrary.simpleMessage(
      "Não autorizado para este acesso",
    ),
    "loginFooter": MessageLookupByLibrary.simpleMessage(
      "Acesso restrito · somente administradores",
    ),
    "loginSubtitle": MessageLookupByLibrary.simpleMessage(
      "agenda-loja · somente proprietários",
    ),
    "loginVerifying": MessageLookupByLibrary.simpleMessage("Verificando..."),
    "miniCardMonth": MessageLookupByLibrary.simpleMessage("este mês"),
    "miniCardOccupancy": MessageLookupByLibrary.simpleMessage("ocupação"),
    "miniCardRevenue": MessageLookupByLibrary.simpleMessage("receitas"),
    "navDashboard": MessageLookupByLibrary.simpleMessage("Início"),
    "navServices": MessageLookupByLibrary.simpleMessage("Serviços"),
    "navWorkers": MessageLookupByLibrary.simpleMessage("Workers"),
    "noData": MessageLookupByLibrary.simpleMessage(
      "Sem dados para este período",
    ),
    "periodCustom": MessageLookupByLibrary.simpleMessage("Personalizado"),
    "periodMonth": MessageLookupByLibrary.simpleMessage("Mês"),
    "periodWeek": MessageLookupByLibrary.simpleMessage("Semana"),
    "periodYear": MessageLookupByLibrary.simpleMessage("Ano"),
    "saveCost": MessageLookupByLibrary.simpleMessage("Salvar"),
    "serviceBasePrice": MessageLookupByLibrary.simpleMessage("Preço base"),
    "serviceCost": MessageLookupByLibrary.simpleMessage("Custo material"),
    "serviceMargin": MessageLookupByLibrary.simpleMessage("Margem"),
    "serviceProfitability": MessageLookupByLibrary.simpleMessage(
      "Rentabilidade",
    ),
    "serviceTimesPerformed": MessageLookupByLibrary.simpleMessage(
      "Vezes realizados",
    ),
    "signOut": MessageLookupByLibrary.simpleMessage("Sair"),
    "workerAppointments": MessageLookupByLibrary.simpleMessage("Atendimentos"),
    "workerRanking": MessageLookupByLibrary.simpleMessage("Ranking de workers"),
    "workerRevenue": MessageLookupByLibrary.simpleMessage("Receitas"),
    "workerShare": MessageLookupByLibrary.simpleMessage("% do total"),
    "workerTopServices": MessageLookupByLibrary.simpleMessage("Top serviços"),
  };
}
